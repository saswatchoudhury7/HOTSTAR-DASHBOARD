# Hotstar-dashboard
This repository contains a Power BI dashboard that provides interactive insights and visual analytics on HOTSTAR dataset. The goal of this project is to transform raw data into actionable intelligence, helping stakeholders make informed, data-driven decisions.
